import Foundation

extension Collection {
    var hasElements: Bool { isEmpty == false }
}
