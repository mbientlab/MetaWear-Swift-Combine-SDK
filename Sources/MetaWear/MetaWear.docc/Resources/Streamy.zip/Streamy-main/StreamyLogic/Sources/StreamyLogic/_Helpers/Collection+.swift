import Foundation

public extension Collection {
    var hasElements: Bool { isEmpty == false }
}
