#  MetaWear Swift Combine SDK Demo Project

For an interactive code walkthrough of this barebones project, view the SDK's documentation in Xcode. 
